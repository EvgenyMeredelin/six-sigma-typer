## __six-sigma-typer__

This is a single process data-only CLI interface for the [six-sigma](https://github.com/EvgenyMeredelin/six-sigma) app.